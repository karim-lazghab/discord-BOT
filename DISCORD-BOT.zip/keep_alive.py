from flask import Flask
from threading import Thread

app = Flask('')

@app.route('/')
def home():
    return "Hello. I am alive!"

def run():
  app.run(host='0.0.0.0',port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()
    

'''
All applications should make reasonable attempts to avoid making invalid requests. For example:

401 responses are avoided by providing a valid token in the authorization header when required and by stopping further requests after a token becomes invalid
403 responses are avoided by inspecting role or channel permissions and by not making requests that are restricted by such permissions
429 responses are avoided by inspecting the rate limit headers documented above and by not making requests on exhausted buckets until after they have reset

------------------------------------------
'''